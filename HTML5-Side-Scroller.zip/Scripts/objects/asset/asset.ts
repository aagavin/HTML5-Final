module objects {
    export interface Asset {
        id: string;
        src: string;
    }
}